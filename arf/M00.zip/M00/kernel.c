int main() {interrupt (0x10, 0xE*256+'H', 0, 0, 0);
interrupt (0x10, 0xE*256+'E', 0, 0, 0);
 interrupt (0x10, 0xE*256+'L', 0, 0, 0);
 interrupt (0x10, 0xE*256+'L', 0, 0, 0);
interrupt (0x10, 0xE*256+'O', 0, 0, 0);
interrupt (0x10, 0xE*256+' ', 0, 0, 0);
interrupt (0x10, 0xE*256+' ', 0, 0, 0);
interrupt (0x10, 0xE*256+' ', 0, 0, 0);
 interrupt (0x10, 0xE*256+'W', 0, 0, 0);
 interrupt (0x10, 0xE*256+'O', 0, 0, 0);
 interrupt (0x10, 0xE*256+'R', 0, 0, 0);
 interrupt (0x10, 0xE*256+'L', 0, 0, 0);
interrupt (0x10, 0xE*256+'D', 0, 0, 0);

while(1){}}
